﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_227_Milestone6
{
    public partial class HighScore : Form
    {
        private int levelSize;
        private List<PlayerStats> playerStatsList = new List<PlayerStats>();
        private bool gameWon;
        private string elpTime;

        //constructor
        public HighScore(int levelSize, bool gameWon, string elpTime)
        {
            InitializeComponent();
            this.levelSize = levelSize;
            this.gameWon = gameWon;
            this.elpTime = elpTime;
            getPlayerStats();
            buildForm();
        }

        private void getPlayerStats()
        {
            //open a file using the same path as the .exe file
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"playerStats.txt");
            using (StreamReader file = new StreamReader(path))
            {
                string line;
                while ((line = file.ReadLine()) != null)
                {
                    char[] delimiters = new char[] { ',' }; 
                    string[] plrArr = line.Split(delimiters); 

                    PlayerStats playerObj = new PlayerStats(plrArr[0], plrArr[1], Convert.ToInt16(plrArr[2]));
                    playerStatsList.Add(playerObj);
                }
                file.Close();
            }
            playerStatsList.Sort(); 
        }

        private string getLevel()
        {
            if (levelSize == 10)
            {
                return "Easy";
            }
            else if (levelSize == 16)
            {
                return "Moderate";
            }
            else
            {
                return "Difficult";
            }
        }
        private void buildForm()
        {
            if (this.gameWon)
            {
                this.wonlabel.Text = "You WON in "+ this.elpTime+" seconds!"; //Update the label if you win
                getTopFive(); 
                checkTopFive(); 
            }
            else
            {
                this.wonlabel.Text = "GAME OVER";//Update the label
                getTopFive(); 
            }
        }
        //Verify the new player time beats any record in the player stats list
        private void checkTopFive()
        {
            var subset = playerStatsList.Where(a => a.PlayedLevel == getLevel() && a.PlayTime < int.Parse(this.elpTime)).ToList();

            if (subset.Count() < 5)
            {
                this.enterNameLabel.Enabled = true;
                this.NameTextBox.Enabled = true;
                this.highScoreButton.Enabled = true;
            }
        }
        //Get the top five players for the selected level and build the display
        private void getTopFive()
        {
            int labelPos = 153; 

            //use LINQ
            var playerSubset = from theElement in playerStatsList
                               where theElement.PlayedLevel == getLevel()
                               select theElement;

            foreach (PlayerStats theElement in playerSubset)
            {
                //Create label, set size, location and text for each player
                Label playerLabel = new Label();
                playerLabel.Location = new Point(29, labelPos);
                playerLabel.Size = new Size(49, 17); 
                playerLabel.Text = theElement.PlayerName;

                Label playerLvl = new Label();
                playerLvl.Location = new Point(120, labelPos);
                playerLvl.Size = new Size(55, 17);
                playerLvl.Text = theElement.PlayedLevel;

                Label playerTime = new Label();
                playerTime.Location = new Point(240, labelPos);
                playerTime.Size = new Size(122, 17);
                playerTime.Text = theElement.PlayTime.ToString();

                //Controls to the form
                this.Controls.Add(playerLabel);
                this.Controls.Add(playerLvl);
                this.Controls.Add(playerTime);

                labelPos = labelPos + 30;
            }
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();//Closed the form

            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"playerStats.txt");
            using (StreamWriter sw = new StreamWriter(path, false))
            {
                for (int x = 0; x < playerStatsList.Count; x++)
                {
                    sw.WriteLine(playerStatsList[x].PlayerName + "," + playerStatsList[x].PlayedLevel + "," + playerStatsList[x].PlayTime.ToString());
                }
                sw.Close();
            }
        }
        private void highScoreButton_Click(object sender, EventArgs e)
        {
            //Create new player for the player stat list 
            PlayerStats newScore = new PlayerStats(this.NameTextBox.Text, getLevel(), int.Parse(this.elpTime));
            playerStatsList.Add(newScore);
            playerStatsList.Sort();

            //Query to get a subset of the player stats
            var playerSubset = from theElement in playerStatsList
                               where theElement.PlayedLevel == getLevel()
                               select theElement;
            //Create a new subset list
            var newPlayerSub = playerSubset.ToList();

            //Get the last element in the new subset list and remove the object from the original playerStatsList
            playerStatsList.Remove(newPlayerSub.Last());
            this.NameTextBox.Text = "";
            this.enterNameLabel.Enabled = false;
            this.NameTextBox.Enabled = false;
            this.highScoreButton.Enabled = false;

            MessageBox.Show("Thanks for playing " + newScore.PlayerName + ", your score has been added!");

        }
    }
}
