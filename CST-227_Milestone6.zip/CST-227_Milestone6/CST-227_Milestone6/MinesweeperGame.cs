﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace CST_227_Milestone6
{
    class MinesweeperGame : Grid, IPlayable
    {
        private Label txtTimer = new Label();
        private Label mineNumLabel = new Label();
        private int tmrval = 0;
        private int numMines = 0;
        private Timer MyTimer = new Timer();
        private Button resetBtn = new Button();
        private int gameLevel;
        
        //constructor
        public MinesweeperGame(int gridArry) : base(gridArry)
        {
            addControls(); 
            this.gameLevel = gridArry;
            this.Closing += Window_Closing;
        }
        public void playGame()
        {
            this.Show(); 
        }
        private void addControls()
        {
            //Form properties
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            //Timer label properties and location
            this.txtTimer.Text = "000";
            this.txtTimer.Font = new Font("Times New Roman", 12, FontStyle.Bold);
            this.txtTimer.BackColor = Color.Black;
            this.txtTimer.ForeColor = Color.Red;
            this.txtTimer.Size = new Size(50, 23);
            txtTimer.Location = new Point(this.arraySize * 30 - this.txtTimer.Size.Width, 10);
            Controls.Add(txtTimer);

            //set Mine label properties and location
            this.numMines = randList.Count();
            this.mineNumLabel.Text = padIntFormat(this.numMines); 
            this.mineNumLabel.Font = new Font("Times New Roman", 12, FontStyle.Bold);
            this.mineNumLabel.BackColor = Color.Black;
            this.mineNumLabel.ForeColor = Color.Red;
            this.mineNumLabel.Size = new Size(50, 23);
            mineNumLabel.Location = new Point(5, 10);
            Controls.Add(mineNumLabel);

            //set Reset Button
            this.resetBtn.Text = "";
            this.resetBtn.BackgroundImage = setImage(11);
            this.resetBtn.BackgroundImageLayout = ImageLayout.Stretch;
            this.resetBtn.AutoSize = false;
            this.resetBtn.TabStop = false;
            this.resetBtn.Size = new Size(30, 30); 
            this.resetBtn.Location = new Point(((this.arraySize * 30) / 2) - 15, 10); 
            Controls.Add(this.resetBtn);
            this.resetBtn.MouseClick += new MouseEventHandler(resetBtnHdl);

        }
        public override void Btn_Click(Object sender, MouseEventArgs e)
        {
            Cell clickBtn = sender as Cell;

            if (this.tmrval == 0)
            {
                MyTimer.Interval = (1000); 
                MyTimer.Start();
                MyTimer.Tick += new EventHandler(MyTimer_Tick); 
            }
            if (e.Button == MouseButtons.Right)
            {
                if (clickBtn.getHasFlag()) 
                {
                    clickBtn.BackgroundImage = null;
                    clickBtn.setHasFlag(false);
                    this.numMines = this.numMines + 1;
                    this.mineNumLabel.Text = padIntFormat(this.numMines); 
                    winCheck(); 
                }
                else
                {
                    clickBtn.setHasFlag(true);
                    clickBtn.BackgroundImage = setImage(10);
                    clickBtn.BackgroundImageLayout = ImageLayout.Stretch;
                    this.numMines = this.numMines - 1;
                    this.mineNumLabel.Text = padIntFormat(this.numMines);
                    winCheck(); 
                }               
            }
            else
            {
                if (!clickBtn.getHasFlag())
                {
                    int btnStr = clickBtn.getLiveNeighbors();
                    if (btnStr == 9) 
                    {
                        revealGrid(false); 
                        clickBtn.BackColor = Color.Red; 
                        MyTimer.Stop();
                        this.resetBtn.BackgroundImage = setImage(12);
                        this.resetBtn.BackgroundImageLayout = ImageLayout.Stretch;

                        //Displays the High Score form
                        HighScore newHighScoreWin = new HighScore(gameLevel, false, txtTimer.Text);
                        newHighScoreWin.Owner = this;
                        newHighScoreWin.Show();
                    }
                    else
                    {
                        clickBtn.Enabled = false; 
                        clickBtn.BackgroundImage = setImage(btnStr); 
                        clickBtn.BackgroundImageLayout = ImageLayout.Stretch;
                        recursiveSearch(clickBtn.getColumn(), clickBtn.getRow()); 
                        winCheck(); //Checks if the player has won the game
                    }
                }
            }

        }
        private void MyTimer_Tick(object sender, EventArgs e)
        {
            Timer tmr = sender as Timer;
            this.tmrval = this.tmrval + 1;
            if (this.tmrval < 1000) 
            {
                this.txtTimer.Text = padIntFormat(this.tmrval);
            }
            else 
            {
                tmr.Stop();
            }

        }
  
        private string padIntFormat(int intToFormat)
        {
            int decimalLength;

            if (intToFormat < -9) 
            {
                decimalLength = intToFormat.ToString("D").Length + 0;  
            }
            else if (intToFormat < 0) 
            {
                decimalLength = intToFormat.ToString("D").Length + 1; 
            }

            else if (intToFormat < 10) 
            {
                decimalLength = intToFormat.ToString("D").Length + 2;  
            }
            else if (intToFormat < 100) 
            {
                decimalLength = intToFormat.ToString("D").Length + 1;
            }
            else 
            {
                decimalLength = intToFormat.ToString("D").Length + 0;
            }
            return intToFormat.ToString("D" + decimalLength.ToString()); ;

        }

        //Verifies if the player won
        private void winCheck()
        {
            int nVisits = visitCheck(); 
            if (nVisits == randList.Count) 
            {
                MyTimer.Stop();
                this.mineNumLabel.Text = 0.ToString(); 
                revealGrid(true); 
                this.resetBtn.BackgroundImage = setImage(13); 
                this.resetBtn.BackgroundImageLayout = ImageLayout.Stretch;

                //Displays the High Score form
                HighScore newHighScoreWin = new HighScore(gameLevel, true, txtTimer.Text);
                newHighScoreWin.Owner = this;
                newHighScoreWin.Show();

            }
        }
        //Recursive search to reveal blocks with no live neighbors.
        private void recursiveSearch(int row, int col)
        {
            if (this.boardArray[col, row].getLiveNeighbors() == 0 && !this.boardArray[col, row].getVisited())
            {
                //set the Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Enabled = false;
                this.boardArray[col, row].BackgroundImage = setImage(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].BackgroundImageLayout = ImageLayout.Stretch;

                if (col - 1 >= 0 && !this.boardArray[col - 1, row].getLive())
                {
                    recursiveSearch(row, col - 1);
                }
                if (col + 1 < this.arraySize && !this.boardArray[col + 1, row].getLive())
                {
                    recursiveSearch(row, col + 1);
                }
                if (row - 1 >= 0 && !this.boardArray[col, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col);
                }
                if (row + 1 < this.arraySize && !this.boardArray[col, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col);
                }
                if (row - 1 >= 0 && col - 1 >= 0 && !this.boardArray[col - 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col - 1);
                }
                if (row + 1 < this.arraySize && col - 1 >= 0 && !this.boardArray[col - 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col - 1);
                }
                if (row - 1 >= 0 && col + 1 < this.arraySize && !this.boardArray[col + 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col + 1);
                }
                if (row + 1 < this.arraySize && col + 1 < this.arraySize && !this.boardArray[col + 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col + 1);
                }
            }
            else
            {
                //Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Enabled = false;
                this.boardArray[col, row].BackgroundImage = setImage(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].BackgroundImageLayout = ImageLayout.Stretch;
            }
        }

        private void resetBtnHdl(object sender, MouseEventArgs e)
        {
            MinesweeperGame resetForm = new MinesweeperGame(this.arraySize);
            this.boardArray = new Cell[arraySize, arraySize];
            resetForm.Show();
            this.Dispose(false);
            this.Closing += Window_Closing;
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Application.Exit();
        }

    }
}
