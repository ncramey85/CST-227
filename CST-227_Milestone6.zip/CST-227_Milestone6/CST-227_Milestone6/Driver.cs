﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace CST_227_Milestone6
{
    static class Driver
    {
        [STAThread]
        static void Main()
        {
            LevelForm LvlForm = new LevelForm(); //Create the level form
            Application.Run(LvlForm); //Run the form
        }
    }
}
