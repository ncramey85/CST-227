﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace CST_227_Milestone6
{
    abstract class Grid : Form
    {
        public System.Windows.Forms.Appearance Appearance { get; set; }
        protected int arraySize;
        protected Cell[,] boardArray;
        protected int numOfRands;
        protected List<int> randList = new List<int>();


        //Constructor
        public Grid(int arraySize)
        {
            this.arraySize = arraySize;
            this.boardArray = new Cell[arraySize, arraySize];

            //Call methods to fill, randomly activate, find neighbors and display the grid
            fillBoard();
            randActivate();
            findActiveNeighbors();
        }


        //Fill the board 2D array with Cell/Button objects and add them to the interface
        private void fillBoard()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    Cell tmpCell = new Cell();
                    tmpCell.Text = "";
                    tmpCell.AutoSize = false;
                    tmpCell.TabStop = false;
                    tmpCell.Size = new Size(30, 30); 
                    tmpCell.Location = new Point(x * 30, y * 30 + 50); 
                    tmpCell.setRow(y);
                    tmpCell.setColumn(x);
                    this.boardArray[y, x] = tmpCell;
                    Controls.Add(tmpCell);
                    tmpCell.MouseDown += new MouseEventHandler(Btn_Click); 
                }
            }

        }

        public abstract void Btn_Click(Object sender, MouseEventArgs e);

        //Method used to set the button image based on the neighbor value or image type (flag, face, bomb, etc.)
        protected Image setImage(int neighborVal)
        {
            Image btnImg = CST_227_Milestone6.Properties.Resources.img0;
            switch (neighborVal)
            {
                case 0:
                    btnImg = CST_227_Milestone6.Properties.Resources.img0;
                    break;
                case 1:
                    btnImg = CST_227_Milestone6.Properties.Resources.img1;
                    break;
                case 2:
                    btnImg = CST_227_Milestone6.Properties.Resources.img2;
                    break;
                case 3:
                    btnImg = CST_227_Milestone6.Properties.Resources.img3;
                    break;
                case 4:
                    btnImg = CST_227_Milestone6.Properties.Resources.img4;
                    break;
                case 5:
                    btnImg = CST_227_Milestone6.Properties.Resources.img5;
                    break;
                case 6:
                    btnImg = CST_227_Milestone6.Properties.Resources.img6;
                    break;
                case 7:
                    btnImg = CST_227_Milestone6.Properties.Resources.img7;
                    break;
                case 8:
                    btnImg = CST_227_Milestone6.Properties.Resources.img8;
                    break;
                case 9:
                    btnImg = CST_227_Milestone6.Properties.Resources.bomb;
                    break;
                case 10:
                    btnImg = CST_227_Milestone6.Properties.Resources.flagged;
                    break;
                case 11:
                    btnImg = CST_227_Milestone6.Properties.Resources.happy;
                    break;
                case 12:
                    btnImg = CST_227_Milestone6.Properties.Resources.sad;
                    break;
                case 13:
                    btnImg = CST_227_Milestone6.Properties.Resources.win;
                    break;
            }

            return btnImg;
        }

        private void randActivate()
        {
            Random rndVal = new Random();
            this.numOfRands = (int)((this.arraySize * this.arraySize) * 0.2);

            while (randList.Count < this.numOfRands)
            {
                int val = rndVal.Next(0, (this.arraySize * this.arraySize));
                if (!randList.Contains(val))
                {
                    randList.Add(val);
                }
            }

            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (randList.Contains(x * this.arraySize + y))
                    {
                        this.boardArray[y, x].setLive(true);
                        this.boardArray[y, x].setLiveNeighbors(9);
                    }
                }
            }
        }

        private void findActiveNeighbors()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    //Check horizontal and vertical Cell Neighbors 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && this.boardArray[y - 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && this.boardArray[y + 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x - 1 >= 0 && this.boardArray[y, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x + 1 < this.arraySize && this.boardArray[y, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                    //Check Diagonal Cell Neighbors 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x - 1 >= 0 && this.boardArray[y - 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x - 1 >= 0 && this.boardArray[y + 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x + 1 < this.arraySize && this.boardArray[y - 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x + 1 < this.arraySize && this.boardArray[y + 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                }
            }
        }

        //Print the board to Console
        public virtual void revealGrid(bool winBool)
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getLive())
                    {
                        if (winBool == true)
                        {
                            this.boardArray[y, x].BackgroundImage = setImage(10);
                        }
                        else
                        {
                            this.boardArray[y, x].BackgroundImage = setImage(9);
                        }
                        this.boardArray[y, x].Enabled = false;
                        this.boardArray[y, x].BackgroundImageLayout = ImageLayout.Stretch;
                    }
                    else
                    {
                        this.boardArray[y, x].Enabled = false;
                        this.boardArray[y, x].BackgroundImage = setImage(this.boardArray[y, x].getLiveNeighbors()); //Display neighbor number if not active
                        this.boardArray[y, x].BackgroundImageLayout = ImageLayout.Stretch;
                    }
                }
            }
        }
        protected int visitCheck()
        {
            int totalNotVisit = 0;
            for (int row = 0; row < this.arraySize; row++)
            {
                for (int col = 0; col < this.arraySize; col++)
                {
                    if (!this.boardArray[col, row].getVisited())
                    {
                        totalNotVisit = totalNotVisit + 1;
                    }
                }
            }
            return totalNotVisit;
        }
        public void printMessageBoard()
        {
            string gridMessage = "";
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[x, y].getLive())
                    {
                        gridMessage = gridMessage + "*";
                    }
                    else
                    {
                        gridMessage = gridMessage + this.boardArray[x, y].getLiveNeighbors();//.ToString();
                    }

                }
                gridMessage = gridMessage + "\n";
            }
            MessageBox.Show(gridMessage);
        }

        public bool ValCheck()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getLiveNeighbors() == 8)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //Getters
        public int getArrSize()
        {
            return this.arraySize;
        }

        public int getNumOfRands()
        {
            return this.numOfRands;
        }


    }
}

