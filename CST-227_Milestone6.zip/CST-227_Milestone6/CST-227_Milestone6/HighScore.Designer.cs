﻿namespace CST_227_Milestone6
{
    partial class HighScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wonlabel = new System.Windows.Forms.Label();
            this.enterNameLabel = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.highScoreButton = new System.Windows.Forms.Button();
            this.topScoreLabel = new System.Windows.Forms.Label();
            this.playNameLabel = new System.Windows.Forms.Label();
            this.levelLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wonlabel
            // 
            this.wonlabel.AutoSize = true;
            this.wonlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wonlabel.Location = new System.Drawing.Point(124, 9);
            this.wonlabel.Name = "wonlabel";
            this.wonlabel.Size = new System.Drawing.Size(151, 36);
            this.wonlabel.TabIndex = 0;
            this.wonlabel.Text = "Win Filler";
            // 
            // enterNameLabel
            // 
            this.enterNameLabel.AutoSize = true;
            this.enterNameLabel.Enabled = false;
            this.enterNameLabel.Location = new System.Drawing.Point(55, 108);
            this.enterNameLabel.Name = "enterNameLabel";
            this.enterNameLabel.Size = new System.Drawing.Size(87, 17);
            this.enterNameLabel.TabIndex = 1;
            this.enterNameLabel.Text = "Enter Name:";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Enabled = false;
            this.NameTextBox.Location = new System.Drawing.Point(148, 106);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(100, 22);
            this.NameTextBox.TabIndex = 2;
            // 
            // highScoreButton
            // 
            this.highScoreButton.Enabled = false;
            this.highScoreButton.Location = new System.Drawing.Point(265, 104);
            this.highScoreButton.Name = "highScoreButton";
            this.highScoreButton.Size = new System.Drawing.Size(75, 23);
            this.highScoreButton.TabIndex = 3;
            this.highScoreButton.Text = "Enter";
            this.highScoreButton.UseVisualStyleBackColor = true;
            this.highScoreButton.Click += new System.EventHandler(this.highScoreButton_Click);
            // 
            // topScoreLabel
            // 
            this.topScoreLabel.AutoSize = true;
            this.topScoreLabel.Enabled = false;
            this.topScoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topScoreLabel.Location = new System.Drawing.Point(145, 76);
            this.topScoreLabel.Name = "topScoreLabel";
            this.topScoreLabel.Size = new System.Drawing.Size(102, 17);
            this.topScoreLabel.TabIndex = 4;
            this.topScoreLabel.Text = "Top 5 Score:";
            // 
            // playNameLabel
            // 
            this.playNameLabel.AutoSize = true;
            this.playNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playNameLabel.Location = new System.Drawing.Point(29, 153);
            this.playNameLabel.Name = "playNameLabel";
            this.playNameLabel.Size = new System.Drawing.Size(49, 17);
            this.playNameLabel.TabIndex = 5;
            this.playNameLabel.Text = "Name";
            // 
            // levelLabel
            // 
            this.levelLabel.AutoSize = true;
            this.levelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.levelLabel.Location = new System.Drawing.Point(153, 153);
            this.levelLabel.Name = "levelLabel";
            this.levelLabel.Size = new System.Drawing.Size(47, 17);
            this.levelLabel.TabIndex = 6;
            this.levelLabel.Text = "Level";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Location = new System.Drawing.Point(276, 153);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(122, 17);
            this.timeLabel.TabIndex = 7;
            this.timeLabel.Text = "Time (Seconds)";
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(336, 391);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 8;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // HighScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 426);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.levelLabel);
            this.Controls.Add(this.playNameLabel);
            this.Controls.Add(this.topScoreLabel);
            this.Controls.Add(this.highScoreButton);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.enterNameLabel);
            this.Controls.Add(this.wonlabel);
            this.Name = "HighScore";
            this.Text = "High Score Tracker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wonlabel;
        private System.Windows.Forms.Label enterNameLabel;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Button highScoreButton;
        private System.Windows.Forms.Label topScoreLabel;
        private System.Windows.Forms.Label playNameLabel;
        private System.Windows.Forms.Label levelLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Button okButton;
    }
}