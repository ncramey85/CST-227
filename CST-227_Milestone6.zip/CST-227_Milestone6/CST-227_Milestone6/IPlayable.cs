﻿namespace CST_227_Milestone6
{
    public interface IPlayable
    {
        void playGame();
    }
}
