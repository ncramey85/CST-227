﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_227_Milestone6
{
    public partial class LevelForm : Form
    {
        private int gridSize = 10; //Default Grid size will be 10x10
        public LevelForm()
        {
            InitializeComponent();

        }

        //Easy radio button selected
        private void easyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 10;
        }

        //Moderate radio button selected
        private void modRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 16;
        }

        //Difficult radio button selected
        private void diffRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 24;
        }

        //Play Game button clicked and Minesweeper GUI will be displayed with selected level/ grid size
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); //hide the level selection form
            MinesweeperGame playMinesweeper = new MinesweeperGame(this.gridSize); //Create the Minesweeper Grid and pass the level/grid size
            playMinesweeper.playGame(); //play the game, Minesweeper window will be displayed
        }

        //Method used to get the user level selection
        public int getGridSize()
        {
            return this.gridSize;
        }
    }
}
