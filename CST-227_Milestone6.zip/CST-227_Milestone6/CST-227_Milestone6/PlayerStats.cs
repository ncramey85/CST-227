﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CST_227_Milestone6
{
    class PlayerStats : IComparable
    {
        private string playerName;
        private string playedLevel;
        private int playTime;

        //constructor
        public PlayerStats(string name, string level, int time)
        {
            this.playerName = name;
            this.playedLevel = level;
            this.playTime = time;
        }

        //setters and getters
        public string PlayerName { get => playerName; set => playerName = value; }
        public string PlayedLevel { get => playedLevel; set => playedLevel = value; }
        public int PlayTime { get => playTime; set => playTime = value; }

        //compare the play time for sorting.
        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return 1;
            }

            PlayerStats otherPlyObj = obj as PlayerStats;
            if (otherPlyObj != null)
            {
                return this.playTime.CompareTo(otherPlyObj.playTime);
            }

            else
            {
                throw new ArgumentException("Object is not a Player Stats Object");
            }
        }
    }
}
