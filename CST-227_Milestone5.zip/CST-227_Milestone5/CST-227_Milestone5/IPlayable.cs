﻿namespace CST_227_Milestone5
{
    public interface IPlayable
    {
        void playGame();
    }
}
