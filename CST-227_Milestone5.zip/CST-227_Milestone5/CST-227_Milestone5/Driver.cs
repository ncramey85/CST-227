﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace CST_227_Milestone5
{
    static class Driver
    {
        [STAThread]
        static void Main()
        {
            //Creates a new level 
            LevelForm LvlForm = new LevelForm(); 
            //Runs that levels application 
            Application.Run(LvlForm); 
        }
    }
}
