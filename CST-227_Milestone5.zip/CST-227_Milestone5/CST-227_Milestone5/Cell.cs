﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace CST_227_Milestone_5
{
    class Cell : Button
    {
        private int row;
        private int column;
        private bool visited;
        private bool live;
        private int liveNeighbors;
        private bool hasFlag;

        public Cell()
        {
            //Constructors 
            this.row = -1;
            this.column = -1;
            this.visited = false;
            this.live = false;
            this.liveNeighbors = 0;
        }

        //Getters
        public int getRow()
        {
            return this.row;
        }

        public int getColumn()
        {
            return this.column;
        }

        public bool getVisited()
        {
            return this.visited;
        }

        public bool getLive()
        {
            return this.live;
        }

        public bool getHasFlag()
        {
            return this.hasFlag;
        }

        public int getLiveNeighbors()
        {
            return this.liveNeighbors;
        }

        //Setters
        public void setRow(int row)
        {
            this.row = row;
        }

        public void setColumn(int column)
        {
            this.column = column;
        }

        public void setVisited(bool visited)
        {
            this.visited = visited;
        }

        public void setLive(bool live)
        {
            this.live = live;
        }

        public void setLiveNeighbors(int liveNeighbors)
        {
            this.liveNeighbors = liveNeighbors;
        }

        public void setHasFlag(bool flag)
        {
            this.hasFlag = flag;
        }
    }
}
