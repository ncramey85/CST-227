﻿namespace CST_227_Milestone5
{
    partial class LevelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.radioGroupBox = new System.Windows.Forms.GroupBox();
            this.easyRadioButton = new System.Windows.Forms.RadioButton();
            this.diffRadioButton = new System.Windows.Forms.RadioButton();
            this.modRadioButton = new System.Windows.Forms.RadioButton();
            this.radioGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(87, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 34);
            this.button1.TabIndex = 7;
            this.button1.Text = "Play Game";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioGroupBox
            // 
            this.radioGroupBox.Controls.Add(this.easyRadioButton);
            this.radioGroupBox.Controls.Add(this.diffRadioButton);
            this.radioGroupBox.Controls.Add(this.modRadioButton);
            this.radioGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioGroupBox.Location = new System.Drawing.Point(20, 18);
            this.radioGroupBox.Name = "radioGroupBox";
            this.radioGroupBox.Size = new System.Drawing.Size(137, 138);
            this.radioGroupBox.TabIndex = 6;
            this.radioGroupBox.TabStop = false;
            this.radioGroupBox.Text = "Select Level";
            // 
            // easyRadioButton
            // 
            this.easyRadioButton.AutoSize = true;
            this.easyRadioButton.Checked = true;
            this.easyRadioButton.Location = new System.Drawing.Point(35, 30);
            this.easyRadioButton.Name = "easyRadioButton";
            this.easyRadioButton.Size = new System.Drawing.Size(60, 21);
            this.easyRadioButton.TabIndex = 1;
            this.easyRadioButton.TabStop = true;
            this.easyRadioButton.Text = "Easy";
            this.easyRadioButton.UseVisualStyleBackColor = true;
            this.easyRadioButton.CheckedChanged += new System.EventHandler(this.easyRadioButton_CheckedChanged);
            // 
            // diffRadioButton
            // 
            this.diffRadioButton.AutoSize = true;
            this.diffRadioButton.Location = new System.Drawing.Point(35, 108);
            this.diffRadioButton.Name = "diffRadioButton";
            this.diffRadioButton.Size = new System.Drawing.Size(75, 21);
            this.diffRadioButton.TabIndex = 3;
            this.diffRadioButton.Text = "Difficult";
            this.diffRadioButton.UseVisualStyleBackColor = true;
            this.diffRadioButton.CheckedChanged += new System.EventHandler(this.diffRadioButton_CheckedChanged);
            // 
            // modRadioButton
            // 
            this.modRadioButton.AutoSize = true;
            this.modRadioButton.Location = new System.Drawing.Point(35, 68);
            this.modRadioButton.Name = "modRadioButton";
            this.modRadioButton.Size = new System.Drawing.Size(89, 21);
            this.modRadioButton.TabIndex = 2;
            this.modRadioButton.Text = "Moderate";
            this.modRadioButton.UseVisualStyleBackColor = true;
            this.modRadioButton.CheckedChanged += new System.EventHandler(this.modRadioButton_CheckedChanged);
            // 
            // LevelForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(206, 211);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioGroupBox);
            this.Name = "LevelForm";
            this.Text = "LevelForm";
            this.radioGroupBox.ResumeLayout(false);
            this.radioGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox radioGroupBox;
        private System.Windows.Forms.RadioButton easyRadioButton;
        private System.Windows.Forms.RadioButton diffRadioButton;
        private System.Windows.Forms.RadioButton modRadioButton;
    }
}