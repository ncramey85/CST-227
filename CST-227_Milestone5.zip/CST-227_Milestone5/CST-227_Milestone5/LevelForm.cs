﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_227_Milestone5
{
    public partial class LevelForm : Form
    {
        private int gridSize = 10; //Default Grid 
        public LevelForm()
        {
            InitializeComponent();
        }

        //Easy selected
        private void easyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 10;
        }

        //Moderate selected
        private void modRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 16;
        }

        //Difficult selected
        private void diffRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 24;
        }

        //Play Game button and GUI for Minesweeper will launch
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); //level selection form
            MinesweeperGame playMinesweeper = new MinesweeperGame(this.gridSize); //Create the Minesweeper Grid
            playMinesweeper.playGame(); //Actual game play
        }

        //User level selection
        public int getGridSize()
        {
            return this.gridSize;
        }
    }
}
