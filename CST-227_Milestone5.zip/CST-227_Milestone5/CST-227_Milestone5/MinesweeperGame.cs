﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using CST_227_Milestone_5;

namespace CST_227_Milestone5
{
    class MinesweeperGame : Grid, IPlayable
    {
        private Label txtTimer = new Label();
        private Label mineNumLabel = new Label();
        private int tmrval = 0;
        private int numMines = 0;
        private Timer MyTimer = new Timer();
        private Button resetBtn = new Button();

        //constructor
        public MinesweeperGame(int gridArry) : base(gridArry)
        {
            addControls(); 
            this.Closing += Window_Closing;
        }
        

        //Logic used to implement the game play.
        public void playGame()
        {
            this.Show(); //Show the Minesweeper GUI
        }

        //Method is used to add controls and change the form properties (Make a Minesweeper GUI)
        private void addControls()
        {
            //Set form properties
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            //set timer label properties and location
            this.txtTimer.Text = "000";
            this.txtTimer.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            this.txtTimer.BackColor = Color.Black;
            this.txtTimer.ForeColor = Color.Red;
            this.txtTimer.Size = new Size(50, 25);
            txtTimer.Location = new Point(this.arraySize * 30 - this.txtTimer.Size.Width, 10);
            Controls.Add(txtTimer);

            //set Mine labels
            this.numMines = randList.Count();
            this.mineNumLabel.Text = padIntFormat(this.numMines); //Method used to pad the int with zeroes
            this.mineNumLabel.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            this.mineNumLabel.BackColor = Color.Black;
            this.mineNumLabel.ForeColor = Color.Red;
            this.mineNumLabel.Size = new Size(50, 25);
            mineNumLabel.Location = new Point(5, 10);
            Controls.Add(mineNumLabel);

            //reset button 
            this.resetBtn.Text = "";
            this.resetBtn.BackgroundImage = setImage(11);
            this.resetBtn.BackgroundImageLayout = ImageLayout.Zoom;
            this.resetBtn.AutoSize = false;
            this.resetBtn.TabStop = false;
            this.resetBtn.Size = new Size(50, 47); 
            this.resetBtn.Location = new Point(((this.arraySize * 30) / 2) - 15, 10); 
            Controls.Add(this.resetBtn);
            this.resetBtn.MouseClick += new MouseEventHandler(resetBtnHdl); //Event

        }

        //right and left mouse clicks constructors
        public override void Btn_Click(Object sender, MouseEventArgs e)
        {
            Cell clickBtn = sender as Cell;

            //Start the timer if the timer value is == 0
            if (this.tmrval == 0)
            {
                MyTimer.Interval = (1000); // 1 second 
                MyTimer.Start();
                MyTimer.Tick += new EventHandler(MyTimer_Tick); 
            }

            //
            if (e.Button == MouseButtons.Right) //right button click for finding the red flag
            {
                if (clickBtn.getHasFlag()) //right button click 
                {
                    clickBtn.BackgroundImage = null;
                    clickBtn.setHasFlag(false);
                    this.numMines = this.numMines + 1;
                    this.mineNumLabel.Text = padIntFormat(this.numMines); //update the flagged mine count 
                    winCheck(); //Check if the player has won the game
                }
                else
                {
                    //flag and mine update 
                    clickBtn.setHasFlag(true);
                    clickBtn.BackgroundImage = setImage(10);
                    clickBtn.BackgroundImageLayout = ImageLayout.Zoom;
                    this.numMines = this.numMines - 1;
                    this.mineNumLabel.Text = padIntFormat(this.numMines);
                    winCheck(); 
                }               
            }
            else
            {
                if (!clickBtn.getHasFlag())
                {
                    //Change the selected Cell/Button properties and complete a recursive search
                    int btnStr = clickBtn.getLiveNeighbors();
                    if (btnStr == 9) 
                    {
                        revealGrid(false); 
                        clickBtn.BackColor = Color.Red; //when flagged cell turns red
                        MyTimer.Stop();
                        this.resetBtn.BackgroundImage = setImage(12);
                        this.resetBtn.BackgroundImageLayout = ImageLayout.Zoom;
                        MessageBox.Show("Game Over!"); 
                    }
                    else
                    {
                        clickBtn.Enabled = false; 
                        clickBtn.BackgroundImage = setImage(btnStr); 
                        clickBtn.BackgroundImageLayout = ImageLayout.Zoom;
                        recursiveSearch(clickBtn.getColumn(), clickBtn.getRow()); //Complete a recursive Search
                        winCheck(); //checks to see if user won game
                    }
                }
            }

        }

        //Timer Label Event 
        private void MyTimer_Tick(object sender, EventArgs e)
        {
            Timer tmr = sender as Timer;
            this.tmrval = this.tmrval + 1;

           
            if (this.tmrval < 1000) //updates the timer label 
            {
                this.txtTimer.Text = padIntFormat(this.tmrval);//update the timer count label
            }
            else //if timer exceeds 999 seconds, it stops counting
            {
                tmr.Stop();
            }

        }

        //Label format 
        private string padIntFormat(int intToFormat)
        {

            int decimalLength;

            //logic needed to pad the label 
            if (intToFormat < -9) 
            {
                decimalLength = intToFormat.ToString("D").Length + 0; //add zeroes 
            }
            else if (intToFormat < 0) 
            {
                decimalLength = intToFormat.ToString("D").Length + 1; //add zeroes 
            }

            else if (intToFormat < 10) 
            {
                decimalLength = intToFormat.ToString("D").Length + 2; //add zeroes 
            }
            else if (intToFormat < 100) 
            {
                decimalLength = intToFormat.ToString("D").Length + 1;
            }
            else 
            {
                decimalLength = intToFormat.ToString("D").Length + 0;
            }
            return intToFormat.ToString("D" + decimalLength.ToString()); ;

        }
        //Verify's if player won the game 
        private void winCheck()
        {
            int nVisits = visitCheck(); //checks to see how many cells visited 
            if (nVisits == randList.Count) 
            {
                MyTimer.Stop();
                this.mineNumLabel.Text = 0.ToString(); //All mines found (not clicked)
                revealGrid(true); //reveal the grid with flags
                this.resetBtn.BackgroundImage = setImage(13); //Imagine will display..........................
                this.resetBtn.BackgroundImageLayout = ImageLayout.Zoom;
                MessageBox.Show("You WIN \n\n Time elapsed: " + txtTimer.Text + " seconds."); //lets user know how long it took to win.

            }
        }
        //Recursive search .
        private void recursiveSearch(int row, int col)
        {
            if (this.boardArray[col, row].getLiveNeighbors() == 0 && !this.boardArray[col, row].getVisited())
            {
                //set the Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Enabled = false;
                this.boardArray[col, row].BackgroundImage = setImage(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].BackgroundImageLayout = ImageLayout.Stretch;

                if (col - 1 >= 0 && !this.boardArray[col - 1, row].getLive())
                {
                    recursiveSearch(row, col - 1);
                }
                if (col + 1 < this.arraySize && !this.boardArray[col + 1, row].getLive())
                {
                    recursiveSearch(row, col + 1);
                }
                if (row - 1 >= 0 && !this.boardArray[col, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col);
                }
                if (row + 1 < this.arraySize && !this.boardArray[col, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col);
                }
                //Check Diagonal Cell Neighbors 
                if (row - 1 >= 0 && col - 1 >= 0 && !this.boardArray[col - 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col - 1);
                }
                if (row + 1 < this.arraySize && col - 1 >= 0 && !this.boardArray[col - 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col - 1);
                }
                if (row - 1 >= 0 && col + 1 < this.arraySize && !this.boardArray[col + 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col + 1);
                }
                if (row + 1 < this.arraySize && col + 1 < this.arraySize && !this.boardArray[col + 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col + 1);
                }
            }
            else
            {
                //set the Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Enabled = false;
                this.boardArray[col, row].BackgroundImage = setImage(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].BackgroundImageLayout = ImageLayout.Stretch;
            }
        }
        //Resets the game 
        private void resetBtnHdl(object sender, MouseEventArgs e)
        {
            MinesweeperGame resetForm = new MinesweeperGame(this.arraySize);
            this.boardArray = new Cell[arraySize, arraySize];
            resetForm.Show();
            this.Dispose(false);
            this.Closing += Window_Closing;
        }

        //Closes the application 
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Application.Exit();
        }

    }
}
