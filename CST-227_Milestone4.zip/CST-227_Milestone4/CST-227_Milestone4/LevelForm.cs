﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_227_Milestone4
{
    public partial class LevelForm : Form
    {
        //default grid is 10x10
        private int gridSize = 10; 
        public LevelForm()
        {
            InitializeComponent();
        }

        //Easy radio button 
        private void easyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 10;
        }

        //Medium radio button
        private void modRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 16;
        }

        //Difficult radio button
        private void diffRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.gridSize = 24;
        }

        //Play Game button clicked so the window will close
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Method used to get the user level selection
        public int getGridSize()
        {
            return this.gridSize;
        }

    }
}
