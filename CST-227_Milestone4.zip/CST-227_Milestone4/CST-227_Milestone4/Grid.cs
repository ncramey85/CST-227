﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;


namespace CST_227_Milestone4
{
    class Grid : Form
    {
        public System.Windows.Forms.Appearance Appearance { get; set; }
        protected int arraySize;
        protected Cell[,] boardArray;
        protected int numOfRands;

        //Constructor
        public Grid(int arraySize)
        {
            this.arraySize = arraySize;
            this.boardArray = new Cell[arraySize, arraySize];

            //Call methods to fill, randomly activate, find neighbors and display the grid
            fillBoard();
            randActivate();
            findActiveNeighbors();
            addControls(); 
        }

        private void addControls()
        {
            //Set form properties
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        }

        //Fill the board 2D array with Cell/Button objects and add them to the interface
        private void fillBoard()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    Cell tmpCell = new Cell();
                    tmpCell.Text = "";
                    tmpCell.AutoSize = false;
                    tmpCell.TabStop = false;
                    tmpCell.Size = new Size(30, 30); 
                    tmpCell.Location = new Point(x * 30, y * 30+50); 
                    tmpCell.setRow(y);
                    tmpCell.setColumn(x);
                    this.boardArray[y, x] = tmpCell;
                    Controls.Add(tmpCell);
                    tmpCell.MouseDown += new MouseEventHandler(Btn_Click);
                }
            }

        }

        protected void Btn_Click(Object sender, MouseEventArgs e)
        {
            Cell clickBtn = sender as Cell;
            if (e.Button == MouseButtons.Right)
            {
                clickBtn.BackColor = Color.Red; //for flags of possible bombs
            }
            else
            {
                //Change the selected Cell/Button properties and complete a recursive search
                int btnStr = clickBtn.getLiveNeighbors();
                clickBtn.Text = clickBtn.getLiveNeighbors().ToString();
                clickBtn.TextAlign = ContentAlignment.MiddleCenter;
                clickBtn.BackColor = Color.Azure;
                clickBtn.ForeColor = setColor(btnStr); 
                clickBtn.Font = new Font(clickBtn.Font.FontFamily, 12, FontStyle.Bold);
                recursiveSearch(clickBtn.getColumn(), clickBtn.getRow()); 
            }

        }
        private Color setColor(int neighborVal)
        {
            Color txtColor = Color.Black;
            switch (neighborVal)
            {
                case 1:
                    txtColor = Color.Blue;
                    break;
                case 2:
                    txtColor = Color.DarkBlue;
                    break;
                case 3:
                    txtColor = Color.Red;
                    break;
                case 4:
                    txtColor = Color.Green;
                    break;
                case 5:
                    txtColor = Color.Black;
                    break;
                case 6:
                    txtColor = Color.Purple;
                    break;
                case 7:
                    txtColor = Color.Yellow;
                    break;
                case 8:
                    txtColor = Color.Gray;
                    break;
            }

            return txtColor;
        }
        private void recursiveSearch(int row, int col)
        {
            if (this.boardArray[col, row].getLiveNeighbors() == 0 && !this.boardArray[col, row].getVisited())
            {
                //set the Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Text = this.boardArray[col, row].getLiveNeighbors().ToString();
                this.boardArray[col, row].TextAlign = ContentAlignment.MiddleCenter;
                this.boardArray[col, row].BackColor = Color.Azure;
                this.boardArray[col, row].ForeColor = setColor(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].Font = new Font(this.boardArray[col, row].Font.FontFamily, 12, FontStyle.Bold);

                if (col - 1 >= 0 && !this.boardArray[col - 1, row].getLive())
                {
                    recursiveSearch(row, col - 1);
                }
                if (col + 1 < this.arraySize && !this.boardArray[col + 1, row].getLive())
                {
                    recursiveSearch(row, col + 1);
                }
                if (row - 1 >= 0 && !this.boardArray[col, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col);
                }
                if (row + 1 < this.arraySize && !this.boardArray[col, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col);
                }
                if (row - 1 >= 0 && col - 1 >= 0 && !this.boardArray[col - 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col - 1);
                }
                if (row + 1 < this.arraySize && col - 1 >= 0 && !this.boardArray[col - 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col - 1);
                }
                if (row - 1 >= 0 && col + 1 < this.arraySize && !this.boardArray[col + 1, row - 1].getLive())
                {
                    recursiveSearch(row - 1, col + 1);
                }
                if (row + 1 < this.arraySize && col + 1 < this.arraySize && !this.boardArray[col + 1, row + 1].getLive())
                {
                    recursiveSearch(row + 1, col + 1);
                }
            }
            else
            {
                //set the Cell/Button properties
                this.boardArray[col, row].setVisited(true);
                this.boardArray[col, row].Text = this.boardArray[col, row].getLiveNeighbors().ToString();
                this.boardArray[col, row].TextAlign = ContentAlignment.MiddleCenter;
                this.boardArray[col, row].BackColor = Color.Azure;
                this.boardArray[col, row].ForeColor = setColor(this.boardArray[col, row].getLiveNeighbors());
                this.boardArray[col, row].Font = new Font(this.boardArray[col, row].Font.FontFamily, 12, FontStyle.Bold);
            }
        }

        //This method is used to randomly activate ~20 percent of the cells in the 2D array
        private void randActivate()
        {
            List<int> randList = new List<int>();
            Random rndVal = new Random();
            this.numOfRands = (int)((this.arraySize * this.arraySize) * 0.2);

            while (randList.Count < this.numOfRands)
            {
                int val = rndVal.Next(0, (this.arraySize * this.arraySize));
                if (!randList.Contains(val))
                {
                    randList.Add(val);
                    //Console.WriteLine(val);
                }
            }

            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (randList.Contains(x * this.arraySize + y))
                    {
                        this.boardArray[y, x].setLive(true);
                        this.boardArray[y, x].setLiveNeighbors(9);
                    }
                }
            }
        }


        //Find the active neighbors and Update the Neighbor Count
        private void findActiveNeighbors()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    //Check horizontal and vertical Cell Neighbors 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && this.boardArray[y - 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && this.boardArray[y + 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x - 1 >= 0 && this.boardArray[y, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x + 1 < this.arraySize && this.boardArray[y, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                    //Check Diagonal Cell Neighbors 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x - 1 >= 0 && this.boardArray[y - 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x - 1 >= 0 && this.boardArray[y + 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x + 1 < this.arraySize && this.boardArray[y - 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x + 1 < this.arraySize && this.boardArray[y + 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                }
            }
        }


        //Creates string representation of the the maze (reaveal)
        public void printBoard()
        {
            string gridMessage = "";
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[x, y].getLive())
                    {
                        gridMessage = gridMessage + "*";
                    }
                    else
                    {
                        gridMessage = gridMessage + this.boardArray[x, y].getLiveNeighbors();
                    }

                }
                gridMessage = gridMessage + "\n";
            }
            MessageBox.Show(gridMessage);
        }


        //Check Cell live Neighbor
        public bool ValCheck()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getLiveNeighbors() == 8)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //Getters
        public int getArrSize()
        {
            return this.arraySize;
        }

        public int getNumOfRands()
        {
            return this.numOfRands;
        }
    }
}
