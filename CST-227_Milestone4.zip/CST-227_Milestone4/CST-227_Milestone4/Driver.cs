﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace CST_227_Milestone4
{
    static class Driver
    {
        [STAThread]
        static void Main()
        {
            //Generates the level of difficulty
            LevelForm LvlForm = new LevelForm(); 
            Application.Run(LvlForm);

            //Determines level difficulty by input from the user
            Grid Form1 = new Grid(LvlForm.getGridSize()); 
            Application.Run(Form1); 


        }
    }
}
