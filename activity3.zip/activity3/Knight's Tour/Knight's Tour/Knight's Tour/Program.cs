﻿using System;

namespace Knight_s_Tour
{
    class Program
    {
        static int BoardSize = 8;
        static int attemptedMoves = 0;
        /* xMove[] and yMove[] define next move of Kinght.
         * xMove[] is for next value of x corrdinate
         * yMove[] is for next value of y coordinate */
        static int[] xMove = { 2, 1, -1, -2, -2, -1, 1, 2 };
        static int[] yMove = { 1, 2, 2, 1, -1, -2, -2, -1 };

        //boardGrid is an 8x8 array that contains -1 for an unvisited square or a move number between 0 and 63.
        static int[,] boardGrid = new int[BoardSize, BoardSize];

        //Driver Code
        static void Main(string[] args)
        {
            solveKT();
            Console.ReadLine();
        }

        /* This function solves the Knight Tour problem using backtracking. This function uses solveKTUtil() to
         * solve the problem. It returns false if no complete tour is possible, otherwise return true and prints the tour. Please not
         * that there may be more than one solution. */
        static void solveKT()
        {
            // Initialization of solution matrix. value of -1 means "not visitied yet"
            for (int x = 0; x < BoardSize; x++)
                for (int y = 0; y < BoardSize; y++)
                    boardGrid[x, y] = -1;
            int startX = 0;
            int startY = 0;
            //set starting position for knight
            boardGrid[startX, startY] = 0;

            //count the total number of fuesses
            attemptedMoves = 0;

            // explore all tours using solveKTUtul()
            if(!solveKTUtil(startX, startY, 1))
            {
                Console.WriteLine("Solution does not exist for {0} {1}", startX, startY);
            }
            else
            {
                printSolution(boardGrid);
                Console.WriteLine("Total attempted moves {0}", attemptedMoves);
            }
        }

        static bool solveKTUtil(int x, int y, int moveCount)
        {
            attemptedMoves++;
            if (attemptedMoves % 1000000 == 0) Console.Out.WriteLine("Attempts: {0}", attemptedMoves);

            int k, next_x, next_y;

            //check to see if we have reached a soultion. 64 = moveCount
            if (moveCount == BoardSize * BoardSize)
                return true;

            //Try all next moves from the current coordinate x, y
            for(k = 0; k < 8; k++)
            {
                next_x = x + xMove[k];
                next_y = y + yMove[k];
                if(isSquareSafe(next_x, next_y))
                {
                    boardGrid[next_x, next_y] = moveCount;
                    if (solveKTUtil(next_x, next_y, moveCount + 1))
                        return true;
                    else
                        //backtracking
                        boardGrid[next_x, next_y] = -1;
                }
            }
            return false;
        }

        //A utility function to check if i,j are valid indexes for N*N chessboard
        static bool isSquareSafe(int x, int y)
        {
            return (x >= 0 && x < BoardSize && y >= 0 && y < BoardSize && boardGrid[x, y] == -1);
        }

        //a utility function to print solution matrix sol[N][N]
        static void printSolution(int[,] solution)
        {
            for(int x = 0; x < BoardSize; x++)
            {
                for(int y = 0; y < BoardSize; y++)
                {
                    Console.Write(solution[x, y] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
