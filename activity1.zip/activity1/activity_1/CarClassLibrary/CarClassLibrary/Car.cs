﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarShopGui
{
	public class Car
	{
		public string Make { get; set; }
		public string Model { get; set; }
		public decimal Price { get; set; }
		public int MPG { get; set; }
		public string Condition { get; set; }

		public Car(string make, string model, decimal price, int mpg, string condition)
		{
			Make = make;
			Model = model;
			Price = price;
			MPG = mpg;
			Condition = condition;
		}

		public Car() {
			Make = "Nothing yet";
			Model = "Nothing yet";
			Price = 0;
			MPG = 0;
			Condition = "Nothing yet";
		}
		public string Display
		{
			get {
				return string.Format("{0} {1} ${2} {3}MPG {4}", Make, Model, Price, MPG, Condition); 
			}
		}
	}
}


