﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarShopGui
{
    public partial class Form1 : Form
    {
        Store store = new Store();
        BindingSource carListBinding = new BindingSource();
        BindingSource shoppingListBinding = new BindingSource();

        public Form1()
        {
            InitializeComponent();
            SetBindings();
        }

        private void SetBindings()
        {
            carListBinding.DataSource = store.CarList;
            carListBox.DataSource = carListBinding;
            carListBox.DisplayMember = "Display";
            carListBox.ValueMember = "Display";

            shoppingListBinding.DataSource = store.ShoppingList;
            shoppingCartListBox.DataSource = shoppingListBinding;
            shoppingCartListBox.DisplayMember = "Display";
            shoppingCartListBox.ValueMember = "Display";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void createCarGroupBox_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void carListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void createCarBtn_Click(object sender, EventArgs e)
        {
            Car newCar = new Car();

            try
            {
                if (makeTextBox.Text.Equals(""))
                {
                    throw new Exception("Make of car is empty.");
                }
                else
                {
                    newCar.Make = makeTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (modelTextBox.Text.Equals(""))
                {
                    throw new Exception("Model of car is empty");
                }
                else
                {
                    newCar.Model = modelTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (Decimal.Parse(priceTextBox.Text) <= 0)
                {
                    throw new Exception("Price of the car is empty");
                }
                else
                {
                    newCar.Price = Decimal.Parse(priceTextBox.Text);
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (mpgTextBox.Text.Equals(""))
                {
                    throw new Exception("MPG of the car is required");
                }
                else
                {
                    //newCar.MPG = mpgTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (conditionTextBox.Text.Equals(""))
                {
                    throw new Exception("Condition of the car is required");
                }
                else
                {
                    newCar.Condition = conditionTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (!newCar.Make.Equals("") && !newCar.Model.Equals("") && newCar.Price != 0 && newCar.MPG != 0 && !newCar.Condition.Equals("")) {

                store.CarList.Add(newCar);
                makeTextBox.Clear();
                modelTextBox.Clear();
                priceTextBox.Clear();
                mpgTextBox.Clear();
                conditionTextBox.Clear();

                carListBinding.ResetBindings(false);
            }
            
        }
        private void addToCartBtn_Click(object sender, EventArgs e)
        {
            store.ShoppingList.Add((Car)carListBox.SelectedItem);

            shoppingListBinding.ResetBindings(false);
        }

        private void checkoutBtn_Click(object sender, EventArgs e)
        {
            decimal total = store.checkout();
            totalCostOutputLabel.Text = total.ToString();
        }

        private void totalCostLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
