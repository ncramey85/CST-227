﻿namespace CarShopGui
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createCarGroupBox = new System.Windows.Forms.GroupBox();
            this.conditionTextBox = new System.Windows.Forms.TextBox();
            this.mpgTextBox = new System.Windows.Forms.TextBox();
            this.conditionLabel = new System.Windows.Forms.Label();
            this.mpgLabel = new System.Windows.Forms.Label();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.modelTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.priceLabel = new System.Windows.Forms.Label();
            this.modelLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.createBtn = new System.Windows.Forms.Button();
            this.carGroupBox = new System.Windows.Forms.GroupBox();
            this.carListBox = new System.Windows.Forms.ListBox();
            this.shoppingCartListBox = new System.Windows.Forms.ListBox();
            this.shoppingCartGroupBox = new System.Windows.Forms.GroupBox();
            this.cartBtn = new System.Windows.Forms.Button();
            this.checkoutBtn = new System.Windows.Forms.Button();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalCostOutputLabel = new System.Windows.Forms.Label();
            this.createCarGroupBox.SuspendLayout();
            this.carGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // createCarGroupBox
            // 
            this.createCarGroupBox.Controls.Add(this.conditionTextBox);
            this.createCarGroupBox.Controls.Add(this.mpgTextBox);
            this.createCarGroupBox.Controls.Add(this.conditionLabel);
            this.createCarGroupBox.Controls.Add(this.mpgLabel);
            this.createCarGroupBox.Controls.Add(this.priceTextBox);
            this.createCarGroupBox.Controls.Add(this.modelTextBox);
            this.createCarGroupBox.Controls.Add(this.makeTextBox);
            this.createCarGroupBox.Controls.Add(this.priceLabel);
            this.createCarGroupBox.Controls.Add(this.modelLabel);
            this.createCarGroupBox.Controls.Add(this.makeLabel);
            this.createCarGroupBox.Location = new System.Drawing.Point(12, 37);
            this.createCarGroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.createCarGroupBox.Name = "createCarGroupBox";
            this.createCarGroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.createCarGroupBox.Size = new System.Drawing.Size(235, 171);
            this.createCarGroupBox.TabIndex = 0;
            this.createCarGroupBox.TabStop = false;
            this.createCarGroupBox.Text = "Create A Car";
            this.createCarGroupBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // conditionTextBox
            // 
            this.conditionTextBox.Location = new System.Drawing.Point(81, 135);
            this.conditionTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.conditionTextBox.Name = "conditionTextBox";
            this.conditionTextBox.Size = new System.Drawing.Size(148, 22);
            this.conditionTextBox.TabIndex = 10;
            // 
            // mpgTextBox
            // 
            this.mpgTextBox.Location = new System.Drawing.Point(81, 109);
            this.mpgTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mpgTextBox.Name = "mpgTextBox";
            this.mpgTextBox.Size = new System.Drawing.Size(148, 22);
            this.mpgTextBox.TabIndex = 9;
            // 
            // conditionLabel
            // 
            this.conditionLabel.AutoSize = true;
            this.conditionLabel.Location = new System.Drawing.Point(4, 138);
            this.conditionLabel.Name = "conditionLabel";
            this.conditionLabel.Size = new System.Drawing.Size(71, 17);
            this.conditionLabel.TabIndex = 8;
            this.conditionLabel.Text = "Condition:";
            // 
            // mpgLabel
            // 
            this.mpgLabel.AutoSize = true;
            this.mpgLabel.Location = new System.Drawing.Point(7, 111);
            this.mpgLabel.Name = "mpgLabel";
            this.mpgLabel.Size = new System.Drawing.Size(43, 17);
            this.mpgLabel.TabIndex = 7;
            this.mpgLabel.Text = "MPG:";
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(81, 83);
            this.priceTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(148, 22);
            this.priceTextBox.TabIndex = 5;
            // 
            // modelTextBox
            // 
            this.modelTextBox.Location = new System.Drawing.Point(81, 57);
            this.modelTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modelTextBox.Name = "modelTextBox";
            this.modelTextBox.Size = new System.Drawing.Size(148, 22);
            this.modelTextBox.TabIndex = 4;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(81, 31);
            this.makeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(148, 22);
            this.makeTextBox.TabIndex = 3;
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(6, 88);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(44, 17);
            this.priceLabel.TabIndex = 2;
            this.priceLabel.Text = "Price:";
            // 
            // modelLabel
            // 
            this.modelLabel.AutoSize = true;
            this.modelLabel.Location = new System.Drawing.Point(6, 64);
            this.modelLabel.Name = "modelLabel";
            this.modelLabel.Size = new System.Drawing.Size(50, 17);
            this.modelLabel.TabIndex = 1;
            this.modelLabel.Text = "Model:";
            // 
            // makeLabel
            // 
            this.makeLabel.AutoSize = true;
            this.makeLabel.Location = new System.Drawing.Point(6, 37);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(46, 17);
            this.makeLabel.TabIndex = 0;
            this.makeLabel.Text = "Make:";
            this.makeLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // createBtn
            // 
            this.createBtn.Location = new System.Drawing.Point(93, 212);
            this.createBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.createBtn.Name = "createBtn";
            this.createBtn.Size = new System.Drawing.Size(89, 34);
            this.createBtn.TabIndex = 6;
            this.createBtn.Text = "Create Car";
            this.createBtn.UseVisualStyleBackColor = true;
            this.createBtn.Click += new System.EventHandler(this.createCarBtn_Click);
            // 
            // carGroupBox
            // 
            this.carGroupBox.Controls.Add(this.carListBox);
            this.carGroupBox.Location = new System.Drawing.Point(252, 37);
            this.carGroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.carGroupBox.Name = "carGroupBox";
            this.carGroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.carGroupBox.Size = new System.Drawing.Size(178, 292);
            this.carGroupBox.TabIndex = 1;
            this.carGroupBox.TabStop = false;
            this.carGroupBox.Text = "Car Inventory";
            // 
            // carListBox
            // 
            this.carListBox.FormattingEnabled = true;
            this.carListBox.ItemHeight = 16;
            this.carListBox.Location = new System.Drawing.Point(6, 21);
            this.carListBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.carListBox.Name = "carListBox";
            this.carListBox.Size = new System.Drawing.Size(167, 260);
            this.carListBox.TabIndex = 0;
            this.carListBox.SelectedIndexChanged += new System.EventHandler(this.carListBox_SelectedIndexChanged);
            // 
            // shoppingCartListBox
            // 
            this.shoppingCartListBox.FormattingEnabled = true;
            this.shoppingCartListBox.ItemHeight = 16;
            this.shoppingCartListBox.Location = new System.Drawing.Point(571, 58);
            this.shoppingCartListBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.shoppingCartListBox.Name = "shoppingCartListBox";
            this.shoppingCartListBox.Size = new System.Drawing.Size(168, 260);
            this.shoppingCartListBox.TabIndex = 2;
            // 
            // shoppingCartGroupBox
            // 
            this.shoppingCartGroupBox.Location = new System.Drawing.Point(565, 37);
            this.shoppingCartGroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.shoppingCartGroupBox.Name = "shoppingCartGroupBox";
            this.shoppingCartGroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.shoppingCartGroupBox.Size = new System.Drawing.Size(178, 292);
            this.shoppingCartGroupBox.TabIndex = 3;
            this.shoppingCartGroupBox.TabStop = false;
            this.shoppingCartGroupBox.Text = "Shopping Cart";
            // 
            // cartBtn
            // 
            this.cartBtn.Location = new System.Drawing.Point(441, 167);
            this.cartBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cartBtn.Name = "cartBtn";
            this.cartBtn.Size = new System.Drawing.Size(114, 33);
            this.cartBtn.TabIndex = 4;
            this.cartBtn.Text = "Add to Cart ->";
            this.cartBtn.UseVisualStyleBackColor = true;
            this.cartBtn.Click += new System.EventHandler(this.addToCartBtn_Click);
            // 
            // checkoutBtn
            // 
            this.checkoutBtn.Location = new System.Drawing.Point(441, 331);
            this.checkoutBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkoutBtn.Name = "checkoutBtn";
            this.checkoutBtn.Size = new System.Drawing.Size(101, 34);
            this.checkoutBtn.TabIndex = 5;
            this.checkoutBtn.Text = "Checkout";
            this.checkoutBtn.UseVisualStyleBackColor = true;
            this.checkoutBtn.Click += new System.EventHandler(this.checkoutBtn_Click);
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(456, 395);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(76, 17);
            this.totalCostLabel.TabIndex = 6;
            this.totalCostLabel.Text = "Total Cost:";
            this.totalCostLabel.Click += new System.EventHandler(this.totalCostLabel_Click);
            // 
            // totalCostOutputLabel
            // 
            this.totalCostOutputLabel.AutoSize = true;
            this.totalCostOutputLabel.Location = new System.Drawing.Point(654, 395);
            this.totalCostOutputLabel.Name = "totalCostOutputLabel";
            this.totalCostOutputLabel.Size = new System.Drawing.Size(0, 17);
            this.totalCostOutputLabel.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 447);
            this.Controls.Add(this.totalCostOutputLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.shoppingCartListBox);
            this.Controls.Add(this.checkoutBtn);
            this.Controls.Add(this.createBtn);
            this.Controls.Add(this.cartBtn);
            this.Controls.Add(this.shoppingCartGroupBox);
            this.Controls.Add(this.carGroupBox);
            this.Controls.Add(this.createCarGroupBox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.createCarGroupBox_Load);
            this.createCarGroupBox.ResumeLayout(false);
            this.createCarGroupBox.PerformLayout();
            this.carGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox createCarGroupBox;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label modelLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.Label conditionLabel;
        private System.Windows.Forms.Label mpgLabel;
        private System.Windows.Forms.Button createBtn;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.TextBox modelTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.TextBox conditionTextBox;
        private System.Windows.Forms.TextBox mpgTextBox;
        private System.Windows.Forms.GroupBox carGroupBox;
        private System.Windows.Forms.ListBox carListBox;
        private System.Windows.Forms.ListBox shoppingCartListBox;
        private System.Windows.Forms.GroupBox shoppingCartGroupBox;
        private System.Windows.Forms.Button cartBtn;
        private System.Windows.Forms.Button checkoutBtn;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label totalCostOutputLabel;
    }
}

