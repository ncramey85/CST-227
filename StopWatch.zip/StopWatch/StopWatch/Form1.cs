﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopWatch
{
    public partial class Form1 : Form
    {
        public static Stopwatch watch = new Stopwatch();
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            watch.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            watch.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            watch.Reset();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = watch.Elapsed.ToString();
            if (random.Next(0,10) < 5)
            {
                button4.Left = random.Next(0, this.Width);
                button4.Top = random.Next(0, this.Height);
                button4.Visible = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
        }
    }
}
