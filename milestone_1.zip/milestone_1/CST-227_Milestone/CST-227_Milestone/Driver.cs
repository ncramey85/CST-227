﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CST_227_Milestone1
{
    class Driver
    {
        static void Main(string[] args)
        {
            //creates the GameBoard and displays the grid on the console
            Grid game1 = new Grid(10);
            Console.WriteLine("Board Array Size = " + game1.getArrSize() + " x " + game1.getArrSize());
            Console.WriteLine("Number of Cells = " + (game1.getArrSize() * game1.getArrSize()));
            Console.WriteLine("Random Live Cells (~20%) = " + game1.getNumOfRandoms());
            game1.printBoard();


            // Testing the logic. Verify correct neighbor count (Cell Neighbor count should be 8 when surrounded by 8 live neighbors.
             
            Console.WriteLine("Looping until a cell with 8 Live Neighbors is discovered");
            bool tmpValue = false;
            while (tmpValue == false)
            {
                Grid game3 = new Grid(20);
                tmpValue = game3.ValueCheck();
                if (tmpValue == true)
                {
                    Console.WriteLine("Board Array = " + game3.getArrSize() + " x " + game3.getArrSize());
                    Console.WriteLine("Number of Cells = " + (game3.getArrSize() * game3.getArrSize()));
                    Console.WriteLine("Random Live Cells (~20%) = " + game3.getNumOfRandoms());
                    game3.printBoard();
                }
            }
            //Console.Clear();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();

        }
    }
}
