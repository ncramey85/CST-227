﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ChessBoardModel
{public class Board
    {     
        public int Size { get; set; }
        public Cell[,] theGrid;

        public Board(int s)
        {
            Size = s;
            theGrid = new Cell[Size, Size];
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++) 
                {
                    theGrid[i, j] = new Cell(i, j);
                }
            }
        }
        public void MarkNextLegalMove(Cell currentCell, string chessPiece)
        {
            for (int r = 0; r < Size; r++)
            {
                for (int c = 0; c < Size; c++)
                {
                    theGrid[r, c].LegalNextMove = false;
                }
            }
            switch (chessPiece )
            {
                case "Knight":
                    if (currentCell.RowNumber - 2 >= 0 && currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 2, currentCell.ColumnNumber - 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber - 2 >= 0 && currentCell.ColumnNumber + 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 2, currentCell.ColumnNumber + 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber + 2 >= 0)
                    { 
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber + 2].LegalNextMove = true; 
                    }
                    if (currentCell.RowNumber + 1 >= 0 && currentCell.ColumnNumber + 2 >= 0)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber + 2].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber + 2 >= 0 && currentCell.ColumnNumber + 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber + 2, currentCell.ColumnNumber + 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber +2 >= 0 && currentCell.ColumnNumber - 1 >= 0) 
                    { 
                        theGrid[currentCell.RowNumber + 2, currentCell.ColumnNumber - 1].LegalNextMove = true; 
                    }
                    if (currentCell.RowNumber +1 >= 0 && currentCell.ColumnNumber -2 >= 0)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber - 2].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber -1 >= 0 && currentCell.ColumnNumber -2 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber - 2].LegalNextMove = true;
                    } 
                    break;

                case "King":
                    if (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                    }
                    if (currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber - 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                    }
                    if (currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber + 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                    }
                    if (currentCell.RowNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    break;

                case "Rook":
                    int rightHorizontalTravel = (Size - 1) - currentCell.ColumnNumber;
                    int leftHorizontalTravel = currentCell.ColumnNumber;
                    int lowerVerticalTravel = (Size - 1) - currentCell.RowNumber;
                    int upperVerticalTravel = currentCell.RowNumber;

                    for (int i = 1; i <= rightHorizontalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber + i].LegalNextMove = true;
                    }
                    for (int i = 1; i <= leftHorizontalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber - i].LegalNextMove = true;
                    }
                    for (int i = 1; i <= upperVerticalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber - i, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    for (int i = 1; i <= lowerVerticalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber + i, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    break;

                case "Bishop":        
                    int originalRow = currentCell.RowNumber;
                    int originalCol = currentCell.ColumnNumber;
                    while (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber - 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber - 1;
                    }
                    currentCell.RowNumber = originalRow;
                    currentCell.ColumnNumber = originalCol;
                    while (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber > 0)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber + 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber - 1;
                    }
                    currentCell.RowNumber = originalRow;
                    currentCell.ColumnNumber = originalCol;
                    while (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber + 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber + 1;
                    }
                    currentCell.RowNumber = originalRow;
                    currentCell.ColumnNumber = originalCol;
                    while (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber - 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber + 1;
                    }
                    currentCell.RowNumber = originalRow;
                    currentCell.ColumnNumber = originalCol;
                    break;

                case "Queen":
                    int queenRightHorizontalTravel = (Size - 1) - currentCell.ColumnNumber;
                    int queenLeftHorizontalTravel = currentCell.ColumnNumber;
                    int queenLowerVerticalTravel = (Size - 1) - currentCell.RowNumber;
                    int queenUpperVerticalTravel = currentCell.RowNumber;

                    for (int i = 1; i <= queenRightHorizontalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber + i].LegalNextMove = true;
                    }
                    for (int i = 1; i <= queenLeftHorizontalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber, currentCell.ColumnNumber - i].LegalNextMove = true;
                    }
                    for (int i = 1; i <= queenUpperVerticalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber - i, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    for (int i = 1; i <= queenLowerVerticalTravel; i++)
                    {
                        theGrid[currentCell.RowNumber + i, currentCell.ColumnNumber].LegalNextMove = true;
                    }
                    int queenOriginalRow = currentCell.RowNumber;
                    int queenOriginalCol = currentCell.ColumnNumber;

                    while (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber - 1 >= 0)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber - 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber - 1;
                    }
                    currentCell.RowNumber = queenOriginalRow;
                    currentCell.ColumnNumber = queenOriginalCol;
                    while (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber > 0)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber - 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber + 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber - 1;
                    }
                    currentCell.RowNumber = queenOriginalRow;
                    currentCell.ColumnNumber = queenOriginalCol;

                    while (currentCell.RowNumber + 1 < Size && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber + 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber + 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber + 1;
                    }
                    currentCell.RowNumber = queenOriginalRow;
                    currentCell.ColumnNumber = queenOriginalCol;

                    while (currentCell.RowNumber - 1 >= 0 && currentCell.ColumnNumber + 1 < Size)
                    {
                        theGrid[currentCell.RowNumber - 1, currentCell.ColumnNumber + 1].LegalNextMove = true;
                        currentCell.RowNumber = currentCell.RowNumber - 1;
                        currentCell.ColumnNumber = currentCell.ColumnNumber + 1;
                    }
                    currentCell.RowNumber = queenOriginalRow;
                    currentCell.ColumnNumber = queenOriginalCol;

                    break;

                default:
                    Console.WriteLine("Input of " + chessPiece + " is not a valid chess piece, no moves to show");
                    break;
            }   
        }
    }
}   
