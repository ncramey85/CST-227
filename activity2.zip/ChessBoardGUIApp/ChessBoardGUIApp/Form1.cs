﻿using ChessBoardModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessBoardGUIApp
{
    public partial class Form1 : Form
    {
        static public Board myboard = new Board(8);
        public Button[,] btnGrid = new Button[myboard.Size, myboard.Size];

        public Form1()
        {
            InitializeComponent();
            populateGrid();
        }
        public void populateGrid()
        {
            int buttonSize = panel1.Width / myboard.Size;
            panel1.Height = panel1.Width; 
            for (int r = 0; r < myboard.Size; r++)
            {
                for(int c = 0; c < myboard.Size; c++)
                {
                    btnGrid[r, c] = new Button();
                    btnGrid[r, c].Width = buttonSize;
                    btnGrid[r, c].Height = buttonSize;
                    btnGrid[r, c].Click += Grid_Button_Click;
                    panel1.Controls.Add(btnGrid[r, c]);
                    btnGrid[r, c].Location = new Point(buttonSize * r, buttonSize * c);

                    //testing 
                    btnGrid[r, c].Text = r.ToString() + "|" + c.ToString();
                    //tag the attribute
                    btnGrid[r, c].Tag = r.ToString() + "|" + c.ToString();
                }
            }
        }
        public void updateButtonLabels()
        {
            for (int r = 0; r < myboard.Size; r++)
            {
                for (int c = 0; c < myboard.Size; c++)
                {
                    btnGrid[r, c].Text = "";
                    if (myboard.theGrid[r, c].CurrentlyOccupied) btnGrid[r, c].Text = "Knight";
                    if (myboard.theGrid[r, c].LegalNextMove) btnGrid[r, c].Text = "Legal";
                }
            }
        }

        private void Grid_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You Clicked the Button");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
