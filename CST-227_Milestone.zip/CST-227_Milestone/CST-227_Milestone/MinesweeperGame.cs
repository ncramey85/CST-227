﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CST_227_Milestone_3
{
    class MinesweeperGame : Grid, IPlay
    {
        
        public MinesweeperGame(int gridArry) : base(gridArry) { }

        //overriding the base class revealGrid 
        public override void revealGrid()
        {
            int xx = 0;
            if (xx == 1)
            {
                base.revealGrid();
            }
            else
            
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getVisited())
                    {
                        if (this.boardArray[y, x].getLiveNeighbors() == 0)
                            {
                                Console.Write("~"); //Active number with no "live" neighbors .
                            }
                        else
                        {
                                Console.Write(this.boardArray[y, x].getLiveNeighbors());// Active number of neighbors
                        }
                    }
                    else {
                            Console.Write("?"); //Displays ? for a cell not visited
                        }
                }
                Console.WriteLine();
            }
            Console.WriteLine("");
        }
        
        //Methods for updating/clearing display
        private void clearAndPrint()
        {
            Console.Clear();
            this.revealGrid();
        }

        //Methods for the game to "play"
        public void playGame()
        {
            bool endGame = false;
            while (endGame == false) { //executes until user hits bomb = end game 
                Console.Write("Enter a row: ");
                int row;
                string rowStr = Console.ReadLine(); // User Row input 
                bool rowIntBool = int.TryParse(rowStr, out row);
                Console.Write("Enter a column: ");
                int col;
                string colStr = Console.ReadLine(); // User column input 
                bool colIntBool = int.TryParse(colStr, out col);

                //Verifies if user "stayed in bounds" 
                if (row < this.arraySize && row > -1 && rowIntBool && col < this.arraySize && col > -1 && colIntBool)
                {
                    if (this.boardArray[col, row].getLive()) //True statement means user lost the game. 
                    {
                        Console.Clear();
                        base.revealGrid();
                        Console.WriteLine("You Lost!");
                        endGame = true;
                    }
                    else
                    {
                        //Checks to see if user visited spot already
                        if (!this.boardArray[col, row].getVisited())
                        {
                            this.boardArray[col, row].setVisited(true);
                            this.clearAndPrint();
                        }
                        else
                        {
                            this.clearAndPrint();
                            Console.WriteLine("Rows '{0}' and columns '{1}' have aleady been picked. Pick something else", rowStr, colStr);
                        }
                        
                    }
                    
                }

                //Input didn't meet the requirements
                else
                {
                    if ((row >= this.arraySize || row < 0) && col < this.arraySize && col > -1 && colIntBool)
                    {
                        this.clearAndPrint();
                        Console.WriteLine("Invalid location for row '{0}'", row);
                    }
                    else if (!rowIntBool && col < this.arraySize && col > -1 && colIntBool)
                    {
                        this.clearAndPrint();
                        Console.WriteLine("Invalid data type for row '{0}'", rowStr);
                    }
                    else if ((col >= this.arraySize || col < 0) && row < this.arraySize && row > -1 && rowIntBool)
                    {
                        this.clearAndPrint();
                        Console.WriteLine("Invalid location for column '{0}'", col);
                    }
                    else if (!colIntBool && row < this.arraySize && row > -1 && rowIntBool)
                    {
                        this.clearAndPrint();
                        Console.WriteLine("Invalid data type for column '{0}'", colStr);
                    }
                    else
                    {
                        this.clearAndPrint();
                        Console.WriteLine("Invalid location or data type for row '{0}' or column '{1}'", rowStr, colStr);
                    }
                    
                }
     
            }
        }
    }

    internal interface IPlay
    {
    }
}