﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CST_227_Milestone2
{
    class Driver
    {
        static void Main(string[] args)
        {
            //Creates object for game play 
            MinesweeperGame game1 = new MinesweeperGame(20);
            game1.playGame();

            //Player lost, closes the game .
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
