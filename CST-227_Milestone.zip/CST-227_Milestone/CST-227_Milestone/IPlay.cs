﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CST_227_Milestone2
{
    public interface IPlay
    {
        void playGame();
    }
}
