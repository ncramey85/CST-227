﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CST_227_Milestone_3
{
    abstract class Grid
    {
        protected int arraySize;
        protected Cells[,] boardArray;
        protected int numberOfRandoms;

        //Constructor
        public Grid(int arraySize)
        {
            this.arraySize = arraySize;
            this.boardArray = new Cells[arraySize, arraySize];

            //Call methods to fill, randomly activate and find neighbors.
            fillBoard();
            randomActivate();
            findActiveNeighbors();
            revealGrid();
        }
        //Fill the board 2D array with Cell objects
        private void fillBoard()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    Cells tmpCell = new Cells();
                    tmpCell.setRow(y);
                    tmpCell.setColumn(x);
                    this.boardArray[y, x] = tmpCell;
                }
            }

        }
        //Method used to randomly activate ~20 percent of the cells within the 2 dimensional array.
        private void randomActivate()
        {
            List<int> randomList = new List<int>();
            Random randomValue = new Random();
            this.numberOfRandoms = (int)((this.arraySize * this.arraySize) * 0.2);

            while (randomList.Count < this.numberOfRandoms)
            {
                int val = randomValue.Next(0, (this.arraySize * this.arraySize));
                if (!randomList.Contains(val))
                {
                    randomList.Add(val);
                }
            }
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (randomList.Contains(x * this.arraySize + y))
                    {
                        this.boardArray[y, x].setLive(true);
                        this.boardArray[y, x].setLiveNeighbors(9);
                    }
                }
            }
        }
        //Locates active neighbors and will update the neighbor Count
        private void findActiveNeighbors()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    //verify horizontal and vertical cell neighbors. 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && this.boardArray[y - 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && this.boardArray[y + 1, x].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x - 1 >= 0 && this.boardArray[y, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && x + 1 < this.arraySize && this.boardArray[y, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                    //verify diagonal cell neighbors 
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x - 1 >= 0 && this.boardArray[y - 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x - 1 >= 0 && this.boardArray[y + 1, x - 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y - 1 >= 0 && x + 1 < this.arraySize && this.boardArray[y - 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }
                    if (!this.boardArray[y, x].getLive() && y + 1 < this.arraySize && x + 1 < this.arraySize && this.boardArray[y + 1, x + 1].getLive())
                    {
                        this.boardArray[y, x].setLiveNeighbors(this.boardArray[y, x].getLiveNeighbors() + 1);
                    }

                }
            }
        }
        //Prints the board to Console
        public virtual void revealGrid()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getLive())
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(this.boardArray[y, x].getLiveNeighbors());
                    }
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n");
        }
        //checks cell live Neighbor for a value of 8
        public bool ValueCheck()
        {
            for (int x = 0; x < this.arraySize; x++)
            {
                for (int y = 0; y < this.arraySize; y++)
                {
                    if (this.boardArray[y, x].getLiveNeighbors() == 8)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        //Getters
        //Attempted to do the {get; set;} format but constructos didn't like this.... 
        public int getArrSize()
        {
            return this.arraySize;
        }
        public int getNumOfRandoms()
        {
            return this.numberOfRandoms;
        }
    }
}
