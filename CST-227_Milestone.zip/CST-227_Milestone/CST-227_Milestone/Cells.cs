﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CST_227_Milestone_3
{
    class Cells
    {
        private int row;
        private int column;
        private bool visited;
        private bool live;
        private int liveNeighbors;

        public Cells()
        {
            //set the variables with default data
            this.row = -1;
            this.column = -1;
            this.visited = false;
            this.live = false;
            this.liveNeighbors = 0;
        }

        //Getters
        //Attempted {get; set; } format but constructors didn't like it... :( 
        public int getRow()
        {
            return this.row;
        }
        public int getColumn()
        {
            return this.column;
        }
        public bool getVisited()
        {
            return this.visited;
        }
        public bool getLive()
        {
            return this.live;
        }
        public int getLiveNeighbors()
        {
            return this.liveNeighbors;
        }

        //Setters
        //Attempted {get; set; } format but constructors didn't like it... :( 
        public void setRow(int row)
        {
            this.row = row;
        }
        public void setColumn(int column)
        {
            this.column = column;
        }
        public void setVisited(bool visited)
        {
            this.visited = visited;
        }
        public void setLive(bool live)
        {
            this.live = live;
        }
        public void setLiveNeighbors(int liveNeighbors)
        {
            this.liveNeighbors = liveNeighbors;
        }
    }
}