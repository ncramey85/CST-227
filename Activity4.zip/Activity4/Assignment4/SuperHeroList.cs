﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity4
{
    static public class SuperHeroList
    {
        static public List<SuperHero> listOfHeros = new List<SuperHero>();

      
    }
}
